import mysql.connector

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="7098",
    database="company"
)

print("Connected to MySQL")
cursor = db.cursor()

cursor.execute("SHOW TABLES")

for table in cursor:
    print(table)

