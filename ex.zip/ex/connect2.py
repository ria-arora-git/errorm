import mysql.connector

db = mysql.connector.connect(host="localhost",user="root",password="7098",database="company")
result = db.cmd_query("""SELECT Fname, Lname, Salary FROM employee ORDER BY Salary DESC""")
(employees, eof) = db.get_rows()
print("First Name      Last Name       Salary")

for emp in employees:
    print("{0:15s} {1:15s} {2:8.2f}".format(emp[0],emp[1],float(emp[2])))

print("\nEnd-of-file:")

for key in eof:
    print("{0:15s} = {1:2d}".format(key, eof[key]))

db.close()