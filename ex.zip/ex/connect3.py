import mysql.connector
import pprint

printer = pprint.PrettyPrinter(indent=1)

db = mysql.connector.connect(host="localhost",user="root",password="7098",database="company")
cursor = db.cursor()
db.start_transaction()
cursor.execute("SELECT Fname, Lname, Salary FROM employee ORDER BY Salary DESC")
before = cursor.fetchall()

print("Employees before the changes:")
print("-"*30)
printer.pprint(before)
print()

cursor.execute("""UPDATE employee SET Salary = Salary + 5000 WHERE Fname = 'John' """)
cursor.execute("SELECT Fname, Lname, Salary FROM employee ORDER BY Salary DESC")
after = cursor.fetchall()

print("Employees after salary update:")
print("-"*30)
printer.pprint(after)
print()

db.rollback()

print("Changes rolled back. Data restored.")

cursor.close()
db.close()