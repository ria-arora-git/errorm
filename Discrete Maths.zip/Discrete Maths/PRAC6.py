# Write a Program to accept a directed graph G and compute the in-degree and out-degree of each vertex.

def degrees(graph):
    n = len(graph)
    in_degree = [0] * n
    out_degree = [0] * n

    for u in range(n):
        out_degree[u] = len(graph[u])
        for v in graph[u]:
            in_degree[v] += 1

    print("Vertex\tIn-degree\tOut-degree")
    for i in range(n):
        print(f"{i}\t{in_degree[i]}\t\t{out_degree[i]}")

graph = {
    0: [1, 2],
    1: [2],
    2: [0, 3],
    3: [3]
}

n = max(graph.keys()) + 1
full_graph = [graph.get(i, []) for i in range(n)]

degrees(full_graph)
