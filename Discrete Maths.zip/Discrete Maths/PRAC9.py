def find_combinations(total, variables):
    if variables == 0:
        return [()] if total == 0 else []

    result = []
    for i in range(total + 1):
        for x in find_combinations(total - i, variables - 1):
            result.append((i,) + x)
    return result

total = 4
variables = 3
combinations = find_combinations(total, variables)

print(combinations)
print(f"\nTotal combinations: {len(combinations)}")


















# def find_combinations(sum, variables):
#     if variables == 0:
#         return [()] if sum == 0 else []

#     all_combinations = []

#     def generate(current_list, remaining_sum, remaining_slots):
#         if remaining_slots == 0:
#             if remaining_sum == 0:
#                 all_combinations.append(tuple(current_list))
#             return
        
#         for value in range(remaining_sum + 1):
#             generate(current_list + [value], remaining_sum - value, remaining_slots - 1)

#     generate([], sum, variables)
#     return all_combinations


# sum = 4 
# variables = 3

# combinations = find_combinations(sum, variables)

# print(combinations)

# print(f"\nTotal combinations: {len(combinations)}")

