# determine whether a given function f is one-one and onto. f from (1,2,3.....n) to set of integers

def check_injective_surjective(function, domain_size, codomain_subset):
    image = [function(x) for x in range(1, domain_size + 1)]

    is_injective = len(set(image)) == domain_size

    is_surjective = set(codomain_subset).issubset(image)

    print("f(x) values (image):", image)
    print("Injective (one-one):", is_injective)
    print("Surjective (onto):", is_surjective)

f = lambda x: x + 1

check_injective_surjective(f, 5, range(2, 7))

g= lambda x: x * 2
check_injective_surjective(g, 5, range(2, 12))








# def check(f, n, target):
#     vals = [f(i) for i in range(1, n + 1)]

#     is_one_one = len(set(vals)) == n

#     is_onto = set(target).issubset(vals)

#     print("Function values:", vals)
#     print("One-one:", is_one_one)
#     print("Onto:", is_onto)

# f = lambda x: x + 1
# check(f, 5, range(2, 7))


