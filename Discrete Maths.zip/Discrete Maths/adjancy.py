# Write a Program to check if a given graph is a complete graph. Represent the graph using the Adjacency Matrix representation.

def complete_graph(adj):
    n = len(adj)
    for i in range(n):
        for j in range(n):
            if i == j:
                if adj[i][j] != 0:
                    return False  
            else:
                if adj[i][j] != 1:
                    return False  
    return True

adj_matrix = [
    [0, 1, 1, 1],
    [1, 0, 1, 1],
    [1, 1, 0, 1],
    [1, 1, 1, 0]
]


print("Graph 1 is complete:" , complete_graph(adj_matrix))

