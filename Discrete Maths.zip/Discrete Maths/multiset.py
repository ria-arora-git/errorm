# given multiset A and B from same universal set find AUB ,A∩B , A-B and A+B

from multiset import Multiset

A = Multiset([1, 2, 2, 3, 3, 3, 4, 5, 5])
B = Multiset([2, 2, 3, 4, 4, 4, 6, 6])

union = A | B
intersection = A & B
difference = A - B

def multiset_to_dict(multiset):
    return {key: value for key, value in sorted(multiset.items())}

A = multiset_to_dict(A)
B = multiset_to_dict(B)

union = multiset_to_dict(union)
intersection = multiset_to_dict(intersection)
difference = multiset_to_dict(difference)

print("A:", A)
print("B:", B)
print("A ∪ B (Union):", union)
print("A ∩ B (Intersection):", intersection)
print("A - B (Difference):", difference)
