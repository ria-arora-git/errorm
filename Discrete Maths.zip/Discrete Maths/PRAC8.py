def polynomial(coef, n):
    result = 0
    degree = len(coef) - 1
    for i in range(len(coef)):
        result += coef[i] * (n ** (degree - i))
    return result

coef = [8, 4, 18]
n = 5
value = polynomial(coef, n)
print(f"Value of the polynomial at n = {n} is: {value}")