# Create a class RELATION, use Matrix notation to represent a relation. Include member functions to check if the relation is Reflexive, Symmetric, Anti-symmetric, Transitive. Using these functions check whether the given relation is: equivalence or partial order relation or none.

class RELATION:
    def __init__(self, matrix):
        self.matrix = matrix
        self.size = len(matrix)

    def is_reflexive(self):
        for i in range(self.size):
            if self.matrix[i][i] != 1:
                return False
        return True

    def is_symmetric(self):
        for i in range(self.size):
            for j in range(self.size):
                if self.matrix[i][j] != self.matrix[j][i]:
                    return False
        return True

    def is_antisymmetric(self):
        for i in range(self.size):
            for j in range(self.size):
                if i != j and self.matrix[i][j] == 1 and self.matrix[j][i] == 1:
                    return False
        return True

    def is_transitive(self):
        for i in range(self.size):
            for j in range(self.size):
                for k in range(self.size):
                    if self.matrix[i][j] == 1 and self.matrix[j][k] == 1 and self.matrix[i][k] != 1:
                        return False
        return True

def get_matrix_input():
    size = int(input("Enter the size of the matrix: "))
    matrix = []
    print("Enter the matrix row by row (space separated):")
    for i in range(size):
        row = list(map(int, input().split()))
        matrix.append(row)
    return matrix

matrix = get_matrix_input()

relation = RELATION(matrix)

print("Reflexive:", relation.is_reflexive())
print("Symmetric:", relation.is_symmetric())
print("Anti-symmetric:", relation.is_antisymmetric())
print("Transitive:", relation.is_transitive())
