#  Write a program that generates all permuatations of the given set of digits , with or without repetition

from itertools import permutations, product

def permutations(digits, length=None, repeat=False):
    if length is None:
        length = len(digits)
    
    if repeat:
        return list(product(digits, repeat=length))  
    else:
        return list(permutations(digits, length))  


digits = [1, 2, 3]
length = 2  

print("Permutations without repetition:")
print(permutations(digits, length, repeat=False))

print("\nPermutations with repetition:")
print(permutations(digits, length, repeat=True))
