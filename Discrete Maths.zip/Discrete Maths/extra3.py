class RELATION:
  def _init_(self, matrix):
    self = matrix

  def is_ref(self):
    for i in range(len(self)):
      if not self[i][i]:
        return False
    return True
  
  def is_symm(self):
    for i in range(len(self)):
      for j in range(len(self)):
        if self[i][j] != self[j][i]:
          return False
    return True
  
  def is_antisymm(self):
    for i in range(len(self)):
      for j in range(len(self)):
        if self[i][j] and self[j][i] and i != j:
          return False
    return True
  
  def is_trans(self):
    for i in range(len (self)):
      for j in range(len (self)):
        for k in range(len (self)):
          if self[i][j] and self[j][k] and not self[i] [k]:
            return False
    return True

matrix =[[1,1,0],
         [1,1,0],
         [0,0,1]]

print("Is reflexive:", RELATION.is_ref(matrix))
print("Is synnetric:", RELATION.is_symm(matrix))
print("Is antisymmetric:", RELATION.is_antisymm(matrix))
print("Is transitive:", RELATION.is_trans(matrix))
