# Create a class SET. Create member functions to perform the following SET operations: 1) ismember: check whether an element belongs to the set or not and return value as true/false. 2)powerset: list all the elements of the power set of a set . 3)subset: Check whether one set is a subset of the other or not. 4)union and Intersection of two Sets. 5)complement: Assume Universal Set as per the input elements from the user. 6)set Difference and Symmetric Difference between two sets. 7) cartesian Product of Sets.

# Write a menu driven program to perform the above functions on an instance of the SET class.

from itertools import chain, combinations

class SET:
    def __init__(self, elements):
        self.elements = set(elements)
    
    def is_member(self, element):
        return element in self.elements
    
    def power_set(self):
        return list(chain.from_iterable(combinations(self.elements, r) for r in range(len(self.elements) + 1)))
    
    def is_subset(self, other_set):
        return self.elements.issubset(other_set.elements)
    
    def union(self, other_set):
        return self.elements.union(other_set.elements)
    
    def intersection(self, other_set):
        return self.elements.intersection(other_set.elements)
    
    def complement(self, universal_set):
        return universal_set.elements - self.elements
    
    def set_difference(self, other_set):
        return self.elements - other_set.elements
    
    def symmetric_difference(self, other_set):
        return self.elements.symmetric_difference(other_set.elements)
    
# Taking input for the main set and universal set
main_set_elements = set(map(int, input("Enter elements of the main set (space-separated): ").split()))
universal_set_elements = set(map(int, input("Enter elements of the universal set (space-separated): ").split()))

main_set = SET(main_set_elements)
universal_set = SET(universal_set_elements)

# Menu-driven interface
while True:
    print("\nMenu:")
    print("1. Check membership")
    print("2. Power set")
    print("3. Check subset")
    print("4. Union and Intersection")
    print("5. Complement")
    print("6. Set Difference and Symmetric Difference")
    print("7. Exit")
    
    choice = int(input("Enter your choice: "))
    
    if choice == 1:
        element = int(input("Enter the element to check: "))
        print("Element is in set:", main_set.is_member(element))
    
    elif choice == 2:
        print("Power set:", main_set.power_set())
    
    elif choice == 3:
        subset_elements = set(map(int, input("Enter elements of another set: ").split()))
        subset_set = SET(subset_elements)
        print("Is subset:", main_set.is_subset(subset_set))
    
    elif choice == 4:
        other_elements = set(map(int, input("Enter elements of another set: ").split()))
        other_set = SET(other_elements)
        print("Union:", main_set.union(other_set))
        print("Intersection:", main_set.intersection(other_set))
    
    elif choice == 5:
        print("Complement:", main_set.complement(universal_set))
    
    elif choice == 6:
        other_elements = set(map(int, input("Enter elements of another set: ").split()))
        other_set = SET(other_elements)
        print("Set Difference:", main_set.set_difference(other_set))
        print("Symmetric Difference:", main_set.symmetric_difference(other_set))
    
    elif choice == 7:
        print("Exiting...")
        break
    
    else:
        print("Invalid choice. Try again.")




# class SET:
#     def __init__(self, elements):
#         self.s = list(elements)

#     def is_member(self, element):
#         return element in self.s

#     def power_set(self):
#         power_set = [[]]
#         for i in self.s:
#             power_set += [subset + [i] for subset in power_set]
#         return power_set

#     def subset(self, other):
#         return all(i in other.s for i in self.s)

#     def union(self, other):
#         return SET(set(self.s) | set(other.s))

#     def intersection(self, other):
#         return SET(set(self.s) & set(other.s))

#     def complement(self, universal):
#         return SET(set(universal.s) - set(self.s))
#     def difference(self, other):
#         return SET(set(self.s) - set(other.s))
#     def symmetric_difference(self, other):
#         return SET(set(self.s) ^ set(other.s))

#     def cartesian_product(self, other):
#         return SET([(i, j) for i in self.s for j in other.s])



# print("1 to check element in set")
# print("2 to find power set")
# print("3 to check subset")
# print("4 to find union")
# print("5 to find intersection")
# print("6 to find complement")
# print("7 to find difference")
# print("8 to find symmetric difference")
# print("9 to find cartesian product")
# print("0 to exit")

# s = SET([{},'' ])
# universal = SET([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# while True:
#     ch = int(input("Enter your choice: "))

#     if ch == 0:
#         break
#     elif ch == 1:
#         element = eval(input("Enter the element to check: "))
#         print(s.is_member(element))
#     elif ch == 2:
#         print(s.power_set())
#     elif ch == 3:
#         other = SET([{1}])
#         print(s.subset(other))
#     elif ch == 4:
#         other = SET([1, 2, 3])
#         print(s.union(other).s)
#     elif ch == 5:
#         other = SET([1, 2, 3])
#         print(s.intersection(other).s)
#     elif ch == 6:
#         print(s.complement(universal).s)
#     elif ch == 7:
#         other = SET([1, 2, 3])
#         print(s.difference(other).s)
#     elif ch == 8:
#         other = SET([1, 2, 3])
#         print(s.symmetric_difference(other).s)
#     elif ch == 9:
#         other = SET([1, 2, 3])
#         print(s.cartesian_product(other).s)
#     else:
#         print("Invalid choice")






# from itertools import chain, combinations

# class SET:
#     def __init__(self, elements=None):
#         if elements is None:
#             self.set = set()
#         else:
#             self.set = set()
#             for elem in elements:
#                 elem = elem.strip()
#                 if elem.startswith('{') and elem.endswith('}'):
#                     inner_set = set(map(int, elem[1:-1].split(',')))
#                     self.set.add(frozenset(inner_set))
#                 else:
#                     try:
#                         self.set.add(int(elem))
#                     except ValueError:
#                         print(f"Invalid element: {elem}")

#     def choose_operation(self):
#         print("Choose an operation:")
#         print("1: Check if element is a member")
#         print("2: Generate the powerset")
#         print("3: Check if given set is a subset of another set")
#         print("4: Union of two sets")
#         print("5: Intersection of two sets")
#         print("6: Complement of a set")
#         print("7: Difference between two sets")
#         print("8: Symmetric difference between two sets")
#         print("9: Cartesian product of two sets")

#         choice = int(input("Enter the operation number: "))

#         if choice == 1:
#             x = input("Enter the element to check: ").strip()
#             try:
#                 x = int(x)
#             except ValueError:
#                 if x.startswith('{') and x.endswith('}'):
#                     x = frozenset(map(int, x[1:-1].split(',')))
#             print("Is member:", self.is_member(x))

#         elif choice == 2:
#             p_set = list(self.powerset())
#             print("Powerset:")
#             print(set(p_set))

#         elif choice == 3:
#             other_elements = input("Enter the elements of the other set separated by commas: ").split(',')
#             other_set = SET(other_elements)
#             print("Is subset:", self.is_subset(other_set))

#         elif choice == 4:
#             other_elements = input("Enter the elements of the other set separated by commas: ").split(',')
#             other_set = SET(other_elements)
#             print("Union:", self.union(other_set))

#         elif choice == 5:
#             other_elements = input("Enter the elements of the other set separated by commas: ").split(',')
#             other_set = SET(other_elements)
#             print("Intersection:", self.intersection(other_set))

#         elif choice == 6:
#             universal_elements = input("Enter the elements of the universal set separated by commas: ").split(',')
#             universal_set = set(map(int, universal_elements))
#             print("Complement:", self.complement(universal_set))

#         elif choice == 7:
#             other_elements = input("Enter the elements of the other set separated by commas: ").split(',')  #self - other
#             other_set = SET(other_elements)
#             print("Difference:", self.set_difference(other_set))

#         elif choice == 8:
#             other_elements = input("Enter the elements of the other set separated by commas: ").split(',')
#             other_set = SET(other_elements)
#             print("Symmetric Difference:", self.symmetric_difference(other_set))

#         elif choice == 9:
#             other_elements = input("Enter the elements of the other set separated by commas: ").split(',')
#             other_set = SET(other_elements)
#             print("Cartesian Product:", self.cartesian_product(other_set))

#         else:
#             print("Invalid operation number!")

#     def is_member(self, x):
#         return x in self.set

#     def powerset(self):
#         s = list(self.set)
#         return chain.from_iterable(combinations(s, r) for r in range(len(s) + 1))

#     def is_subset(self, other_set):
#         return self.set.issubset(other_set.set)

#     def union(self, other_set):
#         return self.set.union(other_set.set)

#     def intersection(self, other_set):
#         return self.set.intersection(other_set.set)

#     def complement(self, universal_set):
#         return universal_set - self.set

#     def set_difference(self, other_set):
#         return self.set - other_set.set

#     def symmetric_difference(self, other_set):
#         return self.set.symmetric_difference(other_set.set)

#     def cartesian_product(self, other_set):
#         return {(a, b) for a in self.set for b in other_set.set}


# set1 = SET(input("Enter the first set (elements separated by commas): ").split(','))
# set1.choose_operation()