#include <iostream>
using namespace std;

void DFS(int graph[10][10], int visited[], int vertex, int vertices)
{
    cout << vertex << " ";

    visited[vertex] = 1;

    for(int i = 0; i < vertices; i++)
    {
        if(graph[vertex][i] == 1 && visited[i] == 0)
        {
            DFS(graph, visited, i, vertices);
        }
    }
}

int main()
{
    int vertices;

    cout << "Enter number of vertices: ";
    cin >> vertices;

    int graph[10][10];

    cout << "Enter adjacency matrix:\n";

    for(int i = 0; i < vertices; i++)
    {
        for(int j = 0; j < vertices; j++)
        {
            cin >> graph[i][j];
        }
    }

    int start;

    cout << "Enter starting vertex: ";
    cin >> start;

    int visited[10] = {0};

    cout << "DFS Traversal:\n";

    DFS(graph, visited, start, vertices);

    return 0;
}


#include <iostream>
#include <vector>
using namespace std;

void DFS(vector<int> graph[], int visited[], int vertex)
{
    cout << vertex << " ";

    visited[vertex] = 1;

    for(int i = 0; i < graph[vertex].size(); i++)
    {
        int next = graph[vertex][i];

        if(visited[next] == 0)
        {
            DFS(graph, visited, next);
        }
    }
}

int main()
{
    int vertices, edges;

    cout << "Enter number of vertices: ";
    cin >> vertices;

    cout << "Enter number of edges: ";
    cin >> edges;

    vector<int> graph[10];

    cout << "Enter edges:\n";

    for(int i = 0; i < edges; i++)
    {
        int u, v;

        cin >> u >> v;

        graph[u].push_back(v);

        graph[v].push_back(u);
    }

    int start;

    cout << "Enter starting vertex: ";
    cin >> start;

    int visited[10] = {0};

    cout << "DFS Traversal:\n";

    DFS(graph, visited, start);

    return 0;
}