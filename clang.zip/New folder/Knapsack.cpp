#include <iostream>
using namespace std;

int main()
{
    int n;

    cout << "Enter number of items: ";
    cin >> n;

    int weight[100], profit[100];

    cout << "Enter weights:\n";

    for(int i = 1; i <= n; i++)
    {
        cin >> weight[i];
    }

    cout << "Enter profits:\n";

    for(int i = 1; i <= n; i++)
    {
        cin >> profit[i];
    }

    int capacity;

    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    int M[100][100];

    for(int w = 0; w <= capacity; w++)
    {
        M[0][w] = 0;
    }

    for(int i = 1; i <= n; i++)
    {
        for(int w = 0; w <= capacity; w++)
        {
            if(weight[i] > w)
            {
                M[i][w] = M[i - 1][w];
            }
            else
            {
                M[i][w] = max(
                    M[i - 1][w],
                    profit[i] + M[i - 1][w - weight[i]]
                );
            }
        }
    }

    cout << "Maximum Profit = " << M[n][capacity];

    return 0;
}