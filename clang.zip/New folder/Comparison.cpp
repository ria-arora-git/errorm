#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iomanip>

using namespace std;

long long comparisons;

void insertionSort(vector<int>& arr)
{
    int n = arr.size();

    for(int i = 1; i < n; i++)
    {
        int key = arr[i];
        int j = i - 1;

        while(j >= 0)
        {
            comparisons++;

            if(arr[j] > key)
            {
                arr[j + 1] = arr[j];
                j--;
            }
            else
            {
                break;
            }
        }

        arr[j + 1] = key;
    }
}

void merge(vector<int>& arr, int low, int mid, int high)
{
    int n1 = mid - low + 1;
    int n2 = high - mid;

    vector<int> L(n1), R(n2);

    for(int i = 0; i < n1; i++)
        L[i] = arr[low + i];

    for(int i = 0; i < n2; i++)
        R[i] = arr[mid + 1 + i];

    int i = 0, j = 0, k = low;

    while(i < n1 && j < n2)
    {
        comparisons++;

        if(L[i] <= R[j])
            arr[k++] = L[i++];
        else
            arr[k++] = R[j++];
    }

    while(i < n1)
        arr[k++] = L[i++];

    while(j < n2)
        arr[k++] = R[j++];
}

void mergeSort(vector<int>& arr, int low, int high)
{
    if(low < high)
    {
        int mid = (low + high) / 2;

        mergeSort(arr, low, mid);
        mergeSort(arr, mid + 1, high);

        merge(arr, low, mid, high);
    }
}

void heapify(vector<int>& arr, int n, int i)
{
    int largest = i;

    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if(left < n)
    {
        comparisons++;

        if(arr[left] > arr[largest])
            largest = left;
    }

    if(right < n)
    {
        comparisons++;

        if(arr[right] > arr[largest])
            largest = right;
    }

    if(largest != i)
    {
        swap(arr[i], arr[largest]);

        heapify(arr, n, largest);
    }
}

void heapSort(vector<int>& arr)
{
    int n = arr.size();

    for(int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    for(int i = n - 1; i > 0; i--)
    {
        swap(arr[0], arr[i]);

        heapify(arr, i, 0);
    }
}

int partition(vector<int>& arr, int low, int high)
{
    int pivot = arr[high];

    int i = low - 1;

    for(int j = low; j < high; j++)
    {
        comparisons++;

        if(arr[j] < pivot)
        {
            i++;

            swap(arr[i], arr[j]);
        }
    }

    swap(arr[i + 1], arr[high]);

    return i + 1;
}

void quickSort(vector<int>& arr, int low, int high)
{
    if(low < high)
    {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

vector<int> generateRandomArray(int n)
{
    vector<int> arr(n);

    for(int i = 0; i < n; i++)
        arr[i] = rand() % 10000;

    return arr;
}

void printGraph(vector<double>& algo, vector<double>& nlogn, string title)
{
    cout << "\n\n" << title << "\n\n";

    double maxVal = 0;

    for(double x : algo)
        if(x > maxVal)
            maxVal = x;

    for(int i = 0; i < algo.size(); i += 5)
    {
        int stars1 = (algo[i] / maxVal) * 50;
        int stars2 = (nlogn[i] / maxVal) * 50;

        cout << setw(4) << (30 + i * (1000 - 30) / 99) << " | ";

        for(int j = 0; j < stars1; j++)
            cout << "*";

        cout << "\n     | ";

        for(int j = 0; j < stars2; j++)
            cout << "+";

        cout << "\n\n";
    }

    cout << "* = Algorithm Comparisons\n";
    cout << "+ = n log n\n";
}

int main()
{
    srand(time(0));

    vector<double> insertionData;
    vector<double> mergeData;
    vector<double> heapData;
    vector<double> quickData;

    vector<double> nlognData;

    for(int step = 0; step < 100; step++)
    {
        int n = 30 + step * (1000 - 30) / 99;

        double insertionAvg = 0;
        double mergeAvg = 0;
        double heapAvg = 0;
        double quickAvg = 0;

        for(int test = 0; test < 10; test++)
        {
            vector<int> original = generateRandomArray(n);

            vector<int> arr1 = original;

            comparisons = 0;

            insertionSort(arr1);

            insertionAvg += comparisons;

            vector<int> arr2 = original;

            comparisons = 0;

            mergeSort(arr2, 0, n - 1);

            mergeAvg += comparisons;

            vector<int> arr3 = original;

            comparisons = 0;

            heapSort(arr3);

            heapAvg += comparisons;

            vector<int> arr4 = original;

            comparisons = 0;

            quickSort(arr4, 0, n - 1);

            quickAvg += comparisons;
        }

        insertionAvg /= 10.0;
        mergeAvg /= 10.0;
        heapAvg /= 10.0;
        quickAvg /= 10.0;

        insertionData.push_back(insertionAvg);
        mergeData.push_back(mergeAvg);
        heapData.push_back(heapAvg);
        quickData.push_back(quickAvg);

        nlognData.push_back(n * log2(n));

        cout << "Completed n = " << n << endl;
    }

    printGraph(insertionData, nlognData, "INSERTION SORT");
    printGraph(mergeData, nlognData, "MERGE SORT");
    printGraph(heapData, nlognData, "HEAP SORT");
    printGraph(quickData, nlognData, "QUICK SORT");

    return 0;
}