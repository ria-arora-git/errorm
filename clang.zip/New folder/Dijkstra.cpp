#include <iostream>
#include <climits>
using namespace std;

int main()
{
    int n;

    cout << "Enter number of vertices: ";
    cin >> n;

    int graph[10][10];

    cout << "Enter adjacency matrix:\n";

    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            cin >> graph[i][j];

    int source;

    cout << "Enter source vertex: ";
    cin >> source;

    int distance[10];
    bool visited[10];

    for(int i = 0; i < n; i++)
    {
        distance[i] = INT_MAX;

        visited[i] = false;
    }

    distance[source] = 0;

    for(int count = 0; count < n - 1; count++)
    {
        int min = INT_MAX;
        int u;

        for(int i = 0; i < n; i++)
        {
            if(!visited[i] && distance[i] <= min)
            {
                min = distance[i];

                u = i;
            }
        }

        visited[u] = true;

        for(int v = 0; v < n; v++)
        {
            if(!visited[v] && graph[u][v] &&
               distance[u] != INT_MAX &&
               distance[u] + graph[u][v] < distance[v])
            {
                distance[v] = distance[u] + graph[u][v];
            }
        }
    }

    cout << "Vertex\tDistance\n";

    for(int i = 0; i < n; i++)
    {
        cout << i << "\t" << distance[i] << endl;
    }

    return 0;
}


// 0 1 4 0
// 1 0 2 6
// 4 2 0 3
// 0 6 3 0