#include <iostream>
#include <queue>
using namespace std;

int main()
{
    int vertices;

    cout << "Enter number of vertices: ";
    cin >> vertices;

    int graph[10][10];

    cout << "Enter adjacency matrix:\n";

    for(int i = 0; i < vertices; i++)
    {
        for(int j = 0; j < vertices; j++)
        {
            cin >> graph[i][j];
        }
    }

    int start;

    cout << "Enter starting vertex: ";
    cin >> start;

    int visited[10] = {0};

    queue<int> q;

    visited[start] = 1;

    q.push(start);

    cout << "BFS Traversal:\n";

    while(!q.empty())
    {
        int node = q.front();

        q.pop();

        cout << node << " ";

        for(int i = 0; i < vertices; i++)
        {
            if(graph[node][i] == 1 && visited[i] == 0)
            {
                visited[i] = 1;

                q.push(i);
            }
        }
    }

    return 0;
}

// 0 1 1 0
// 1 0 0 1
// 1 0 0 1
// 0 1 1 0


#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int main()
{
    int vertices, edges;

    cout << "Enter number of vertices: ";
    cin >> vertices;

    cout << "Enter number of edges: ";
    cin >> edges;

    vector<int> graph[10];

    cout << "Enter edges:\n";

    for(int i = 0; i < edges; i++)
    {
        int u, v;

        cin >> u >> v;

        graph[u].push_back(v);

        graph[v].push_back(u);
    }

    int start;

    cout << "Enter starting vertex: ";
    cin >> start;

    int visited[10] = {0};

    queue<int> q;

    visited[start] = 1;

    q.push(start);

    cout << "BFS Traversal:\n";

    while(!q.empty())
    {
        int node = q.front();

        q.pop();

        cout << node << " ";

        for(int i = 0; i < graph[node].size(); i++)
        {
            int next = graph[node][i];

            if(visited[next] == 0)
            {
                visited[next] = 1;

                q.push(next);
            }
        }
    }

    return 0;
}

// 0 1
// 0 2
// 1 3
// 2 3