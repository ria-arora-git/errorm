# DESIGN AND ANALYSIS OF ALGORITHMS PRACTICALS
# Each program is separate in the ZIP file.



# 01_RANDOMIZED_QUICK_SORT.PY
# Program 1: Randomized Quick Sort
# Sort an array and count the number of comparisons.

import random

comparisons = 0

def partition(arr, low, high):
    global comparisons

    # Choose a random pivot and move it to the last position
    random_index = random.randint(low, high)
    arr[random_index], arr[high] = arr[high], arr[random_index]

    pivot = arr[high]
    i = low - 1

    for j in range(low, high):
        comparisons += 1
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def quick_sort(arr, low, high):
    if low < high:
        p = partition(arr, low, high)
        quick_sort(arr, low, p - 1)
        quick_sort(arr, p + 1, high)


arr = [34, 12, 45, 2, 19, 8, 27]

print("Original array:", arr)
quick_sort(arr, 0, len(arr) - 1)
print("Sorted array:", arr)
print("Number of comparisons:", comparisons)



# 02_RANDOMIZED_SELECT.PY
# Program 2: Randomized Select
# Find the kth smallest element in an array.

import random

def partition(arr, low, high):
    pivot_index = random.randint(low, high)
    arr[pivot_index], arr[high] = arr[high], arr[pivot_index]

    pivot = arr[high]
    i = low - 1

    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def randomized_select(arr, low, high, k):
    if low == high:
        return arr[low]

    p = partition(arr, low, high)
    position = p - low + 1

    if k == position:
        return arr[p]
    elif k < position:
        return randomized_select(arr, low, p - 1, k)
    else:
        return randomized_select(arr, p + 1, high, k - position)


arr = [7, 10, 4, 3, 20, 15]
k = 3

print("Array:", arr)
print(k, "th smallest element:", randomized_select(arr, 0, len(arr) - 1, k))



# 03_KRUSKALS_ALGORITHM.PY
# Program 3: Kruskal's Algorithm
# Find the Minimum Spanning Tree of a weighted graph.

def find(parent, vertex):
    if parent[vertex] != vertex:
        parent[vertex] = find(parent, parent[vertex])
    return parent[vertex]


def union(parent, rank, u, v):
    root_u = find(parent, u)
    root_v = find(parent, v)

    if root_u == root_v:
        return False

    if rank[root_u] < rank[root_v]:
        parent[root_u] = root_v
    elif rank[root_u] > rank[root_v]:
        parent[root_v] = root_u
    else:
        parent[root_v] = root_u
        rank[root_u] += 1

    return True


# Each edge is written as (weight, starting vertex, ending vertex)
edges = [
    (10, 0, 1),
    (6, 0, 2),
    (5, 0, 3),
    (15, 1, 3),
    (4, 2, 3)
]

vertices = 4
parent = list(range(vertices))
rank = [0] * vertices

# Sort edges according to their weight
edges.sort()

mst = []
total_cost = 0

for weight, u, v in edges:
    if union(parent, rank, u, v):
        mst.append((u, v, weight))
        total_cost += weight

print("Edges in Minimum Spanning Tree:")
for u, v, weight in mst:
    print(u, "-", v, ":", weight)

print("Total cost of MST:", total_cost)



# 04_BELLMAN_FORD.PY
# Program 4: Bellman-Ford Algorithm
# Find shortest paths from a source vertex to all other vertices.

vertices = 5

# Each edge contains: (starting vertex, ending vertex, weight)
edges = [
    (0, 1, 6),
    (0, 2, 7),
    (1, 2, 8),
    (1, 3, 5),
    (1, 4, -4),
    (2, 3, -3),
    (2, 4, 9),
    (3, 1, -2),
    (4, 0, 2),
    (4, 3, 7)
]

source = 0
distance = [float("inf")] * vertices
distance[source] = 0

# Relax all edges V-1 times
for i in range(vertices - 1):
    for u, v, weight in edges:
        if distance[u] != float("inf") and distance[u] + weight < distance[v]:
            distance[v] = distance[u] + weight

# Check for a negative weight cycle
negative_cycle = False
for u, v, weight in edges:
    if distance[u] != float("inf") and distance[u] + weight < distance[v]:
        negative_cycle = True
        break

if negative_cycle:
    print("Graph contains a negative weight cycle.")
else:
    print("Shortest distances from source vertex", source)
    for i in range(vertices):
        print("Vertex", i, ":", distance[i])



# 05_B_TREE.PY
# Program 5: B-Tree
# Insert values into a B-Tree and display its keys.

class BTreeNode:
    def __init__(self, leaf=False):
        self.keys = []
        self.children = []
        self.leaf = leaf


class BTree:
    def __init__(self, degree):
        self.root = BTreeNode(True)
        self.degree = degree

    def search(self, node, key):
        i = 0
        while i < len(node.keys) and key > node.keys[i]:
            i += 1

        if i < len(node.keys) and key == node.keys[i]:
            return True

        if node.leaf:
            return False

        return self.search(node.children[i], key)

    def split_child(self, parent, index):
        degree = self.degree
        full_child = parent.children[index]
        new_child = BTreeNode(full_child.leaf)

        middle_key = full_child.keys[degree - 1]

        new_child.keys = full_child.keys[degree:]
        full_child.keys = full_child.keys[:degree - 1]

        if not full_child.leaf:
            new_child.children = full_child.children[degree:]
            full_child.children = full_child.children[:degree]

        parent.children.insert(index + 1, new_child)
        parent.keys.insert(index, middle_key)

    def insert(self, key):
        root = self.root

        # If root is full, create a new root
        if len(root.keys) == 2 * self.degree - 1:
            new_root = BTreeNode(False)
            new_root.children.append(root)
            self.root = new_root
            self.split_child(new_root, 0)
            self.insert_non_full(new_root, key)
        else:
            self.insert_non_full(root, key)

    def insert_non_full(self, node, key):
        i = len(node.keys) - 1

        if node.leaf:
            node.keys.append(0)
            while i >= 0 and key < node.keys[i]:
                node.keys[i + 1] = node.keys[i]
                i -= 1
            node.keys[i + 1] = key
        else:
            while i >= 0 and key < node.keys[i]:
                i -= 1
            i += 1

            if len(node.children[i].keys) == 2 * self.degree - 1:
                self.split_child(node, i)
                if key > node.keys[i]:
                    i += 1

            self.insert_non_full(node.children[i], key)

    def display(self, node, level=0):
        print("Level", level, ":", node.keys)
        for child in node.children:
            self.display(child, level + 1)


tree = BTree(2)  # Minimum degree is 2
values = [10, 20, 5, 6, 12, 30, 7, 17]

for value in values:
    tree.insert(value)

print("B-Tree:")
tree.display(tree.root)

print("Search 12:", tree.search(tree.root, 12))
print("Search 99:", tree.search(tree.root, 99))



# 06_KMP_PATTERN_MATCHING.PY
# Program 6: KMP Pattern Matching
# Find the positions where a pattern occurs in a text.

def create_lps(pattern):
    lps = [0] * len(pattern)
    length = 0
    i = 1

    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        elif length != 0:
            length = lps[length - 1]
        else:
            lps[i] = 0
            i += 1

    return lps


def kmp_search(text, pattern):
    lps = create_lps(pattern)
    i = 0
    j = 0
    positions = []

    while i < len(text):
        if text[i] == pattern[j]:
            i += 1
            j += 1

        if j == len(pattern):
            positions.append(i - j)
            j = lps[j - 1]
        elif i < len(text) and text[i] != pattern[j]:
            if j != 0:
                j = lps[j - 1]
            else:
                i += 1

    return positions


text = "ABABDABACDABABCABAB"
pattern = "ABABCABAB"

print("Text:", text)
print("Pattern:", pattern)
print("LPS array:", create_lps(pattern))
print("Pattern found at index:", kmp_search(text, pattern))



# 07_BRUTEFORCE_SUFFIX_TRIE.PY
# Program 7: Suffix Trie using Brute Force Method
# Insert all suffixes of a text into a trie and search for a pattern.

class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False


class SuffixTrie:
    def __init__(self, text):
        self.root = TrieNode()

        # Insert every suffix of the given text
        for i in range(len(text)):
            self.insert(text[i:])

    def insert(self, suffix):
        current = self.root

        for character in suffix:
            if character not in current.children:
                current.children[character] = TrieNode()
            current = current.children[character]

        current.is_end = True

    def search(self, pattern):
        current = self.root

        for character in pattern:
            if character not in current.children:
                return False
            current = current.children[character]

        return True


text = "banana"
trie = SuffixTrie(text)

print("Text:", text)
print("Search 'ana':", trie.search("ana"))
print("Search 'apple':", trie.search("apple"))

