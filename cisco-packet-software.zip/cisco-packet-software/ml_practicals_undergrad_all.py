# MACHINE LEARNING PRACTICALS - UNDERGRADUATE STYLE
# Each practical is also available separately in the ZIP.

# 01_NAIVE_BAYES.PY
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.naive_bayes import GaussianNB

# Load the breast cancer dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Create Naive Bayes model
model = GaussianNB()

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate confusion matrix values
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)

# Calculate AUC using prediction probabilities
if hasattr(model, "predict_proba"):
    y_prob = model.predict_proba(X_test)[:, 1]
else:
    y_prob = model.decision_function(X_test)

auc = roc_auc_score(y_test, y_prob)

print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("TP:", tp)
print("TN:", tn)
print("FP:", fp)
print("FN:", fn)
print("Accuracy:", accuracy)
print("Error:", error)
print("Recall:", recall)
print("Specificity:", specificity)
print("F1 Score:", f1)
print("AUC:", auc)

# 5-fold cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv)
print("Cross-validation scores:", scores)
print("Average CV accuracy:", scores.mean())


# 02_SIMPLE_LINEAR_REGRESSION.PY
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Load diabetes dataset
data = load_diabetes()
# Take only one column (BMI) for simple linear regression
X = data.data[:, [2]]
y = data.target

# Create Linear Regression model
model = LinearRegression()

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate evaluation scores
print("MSE:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

# 5-fold cross-validation
cv = KFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv, scoring="r2")
print("Cross-validation R2 scores:", scores)
print("Average CV R2:", scores.mean())

# Display the regression line
plt.scatter(X_test, y_test)
plt.plot(X_test, y_pred, color="red")
plt.xlabel("BMI")
plt.ylabel("Diabetes Progression")
plt.title("Simple Linear Regression")
plt.show()


# 03_MULTIPLE_LINEAR_REGRESSION.PY
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression

# Load diabetes dataset
data = load_diabetes()
# Use all input columns
X = data.data
y = data.target

# Create Linear Regression model
model = LinearRegression()

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate evaluation scores
print("MSE:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

# 5-fold cross-validation
cv = KFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv, scoring="r2")
print("Cross-validation R2 scores:", scores)
print("Average CV R2:", scores.mean())

print("Coefficients:", model.coef_)
print("Intercept:", model.intercept_)


# 04_POLYNOMIAL_REGRESSION.PY
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

# Load diabetes dataset
data = load_diabetes()
# Use one input column (BMI)
X = data.data[:, [2]]
y = data.target

# Convert input into polynomial features of degree 2
poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X)
X = X_poly

# Create Linear Regression model
model = LinearRegression()

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X_poly, y, test_size=0.2, random_state=42
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate evaluation scores
print("MSE:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

# 5-fold cross-validation
cv = KFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X_poly, y, cv=cv, scoring="r2")
print("Cross-validation R2 scores:", scores)
print("Average CV R2:", scores.mean())

# Draw the graph
plt.scatter(X_test[:, 1], y_test)
plt.scatter(X_test[:, 1], y_pred, color="red")
plt.xlabel("BMI")
plt.ylabel("Diabetes Progression")
plt.title("Polynomial Regression")
plt.show()


# 05_LASSO_AND_RIDGE_REGRESSION.PY
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import Lasso, Ridge

# Load diabetes dataset
data = load_diabetes()
X = data.data
y = data.target

# LASSO REGRESSION
print("LASSO REGRESSION")
model = Lasso(alpha=0.1)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate evaluation scores
print("MSE:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

# 5-fold cross-validation
cv = KFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv, scoring="r2")
print("Cross-validation R2 scores:", scores)
print("Average CV R2:", scores.mean())

# RIDGE REGRESSION
print("\nRIDGE REGRESSION")
model = Ridge(alpha=1.0)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate evaluation scores
print("MSE:", mean_squared_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

# 5-fold cross-validation
cv = KFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv, scoring="r2")
print("Cross-validation R2 scores:", scores)
print("Average CV R2:", scores.mean())


# 06_LOGISTIC_REGRESSION.PY
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

# Load the breast cancer dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Standardize data and create Logistic Regression model
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate confusion matrix values
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)

# Calculate AUC using prediction probabilities
if hasattr(model, "predict_proba"):
    y_prob = model.predict_proba(X_test)[:, 1]
else:
    y_prob = model.decision_function(X_test)

auc = roc_auc_score(y_test, y_prob)

print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("TP:", tp)
print("TN:", tn)
print("FP:", fp)
print("FN:", fn)
print("Accuracy:", accuracy)
print("Error:", error)
print("Recall:", recall)
print("Specificity:", specificity)
print("F1 Score:", f1)
print("AUC:", auc)

# 5-fold cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv)
print("Cross-validation scores:", scores)
print("Average CV accuracy:", scores.mean())


# 07_ARTIFICIAL_NEURAL_NETWORK.PY
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline

# Load the breast cancer dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Create a neural network with one hidden layer
model = make_pipeline(
    StandardScaler(),
    MLPClassifier(hidden_layer_sizes=(10,), max_iter=1000, random_state=42)
)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate confusion matrix values
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)

# Calculate AUC using prediction probabilities
if hasattr(model, "predict_proba"):
    y_prob = model.predict_proba(X_test)[:, 1]
else:
    y_prob = model.decision_function(X_test)

auc = roc_auc_score(y_test, y_prob)

print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("TP:", tp)
print("TN:", tn)
print("FP:", fp)
print("FN:", fn)
print("Accuracy:", accuracy)
print("Error:", error)
print("Recall:", recall)
print("Specificity:", specificity)
print("F1 Score:", f1)
print("AUC:", auc)

# 5-fold cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv)
print("Cross-validation scores:", scores)
print("Average CV accuracy:", scores.mean())


# 08_KNN_CLASSIFIER.PY
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline

# Load the breast cancer dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Create KNN model with 5 neighbours
model = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5))

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate confusion matrix values
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)

# Calculate AUC using prediction probabilities
if hasattr(model, "predict_proba"):
    y_prob = model.predict_proba(X_test)[:, 1]
else:
    y_prob = model.decision_function(X_test)

auc = roc_auc_score(y_test, y_prob)

print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("TP:", tp)
print("TN:", tn)
print("FP:", fp)
print("FN:", fn)
print("Accuracy:", accuracy)
print("Error:", error)
print("Recall:", recall)
print("Specificity:", specificity)
print("F1 Score:", f1)
print("AUC:", auc)

# 5-fold cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv)
print("Cross-validation scores:", scores)
print("Average CV accuracy:", scores.mean())


# 09_DECISION_TREE_CLASSIFICATION.PY
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

# Load the breast cancer dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Create Decision Tree model
model = DecisionTreeClassifier(random_state=42)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate confusion matrix values
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)

# Calculate AUC using prediction probabilities
if hasattr(model, "predict_proba"):
    y_prob = model.predict_proba(X_test)[:, 1]
else:
    y_prob = model.decision_function(X_test)

auc = roc_auc_score(y_test, y_prob)

print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("TP:", tp)
print("TN:", tn)
print("FP:", fp)
print("FN:", fn)
print("Accuracy:", accuracy)
print("Error:", error)
print("Recall:", recall)
print("Specificity:", specificity)
print("F1 Score:", f1)
print("AUC:", auc)

# 5-fold cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv)
print("Cross-validation scores:", scores)
print("Average CV accuracy:", scores.mean())


# 10_SVM_CLASSIFICATION.PY
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score, f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline

# Load the breast cancer dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Create SVM model with linear kernel
model = make_pipeline(
    StandardScaler(),
    SVC(kernel="linear", probability=True, random_state=42)
)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train the model and make predictions
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Calculate confusion matrix values
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)

# Calculate AUC using prediction probabilities
if hasattr(model, "predict_proba"):
    y_prob = model.predict_proba(X_test)[:, 1]
else:
    y_prob = model.decision_function(X_test)

auc = roc_auc_score(y_test, y_prob)

print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("TP:", tp)
print("TN:", tn)
print("FP:", fp)
print("FN:", fn)
print("Accuracy:", accuracy)
print("Error:", error)
print("Recall:", recall)
print("Specificity:", specificity)
print("F1 Score:", f1)
print("AUC:", auc)

# 5-fold cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv)
print("Cross-validation scores:", scores)
print("Average CV accuracy:", scores.mean())


# 11_KMEANS_CLUSTERING.PY
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Load iris dataset
data = load_iris()
X = data.data

# Scale the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Create K-Means model with 3 clusters
model = KMeans(n_clusters=3, random_state=42, n_init=10)
clusters = model.fit_predict(X_scaled)

print("Cluster labels:", clusters)
print("Cluster centres:\n", model.cluster_centers_)
print("Silhouette Score:", silhouette_score(X_scaled, clusters))

# Display clusters
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=clusters)
plt.xlabel("Sepal Length")
plt.ylabel("Sepal Width")
plt.title("K-Means Clustering")
plt.show()


# 12_HIERARCHICAL_CLUSTERING.PY
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score
from scipy.cluster.hierarchy import linkage, dendrogram

# Load iris dataset
data = load_iris()
X = data.data

# Scale the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Draw dendrogram
linked = linkage(X_scaled, method="ward")
dendrogram(linked)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Data Points")
plt.ylabel("Distance")
plt.show()

# Create Hierarchical Clustering model
model = AgglomerativeClustering(n_clusters=3)
clusters = model.fit_predict(X_scaled)

print("Cluster labels:", clusters)
print("Silhouette Score:", silhouette_score(X_scaled, clusters))
