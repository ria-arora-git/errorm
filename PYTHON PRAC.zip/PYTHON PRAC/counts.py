def string_operations():
    
    input_string = input("Enter a string: ")
    
    # a. Find the frequency of a character in a string
    char_to_find = input("Enter a character to find its frequency: ")
    frequency = input_string.count(char_to_find)
    print(f"Frequency of '{char_to_find}' in the string: {frequency}")

    # b. Replace a character by another character in a string
    char_to_replace = input("Enter the character to replace: ")
    replacement = input("Enter the replacement character: ")
    replaced_string = input_string.replace(char_to_replace, replacement)
    print(f"New string: {replaced_string}")

    # c. Remove the first occurrence of a character from a string
    char_to_remove_first = input("Enter the character to remove the first occurrence: ")
    first_removed_string = input_string.replace(char_to_remove_first, '', 1)
    print(f"String after removing first occurrence of '{char_to_remove_first}': {first_removed_string}")

    # d. Remove all occurrences of a character from a string
    char_to_remove_all = input("Enter the character to remove all occurrences: ")
    all_removed_string = input_string.replace(char_to_remove_all, '')
    print(f"String after removing all occurrences of '{char_to_remove_all}': {all_removed_string}")

string_operations()
