def cubes_of_even_integers(input_list):
    return [item ** 3 for item in input_list if isinstance(item, int) and item % 2 == 0]

input_list = input("Enter a list of values (separated by commas): ").split(',')
input_list = [int(x) if x.isdigit() else x for x in input_list]
print(cubes_of_even_integers(input_list))
