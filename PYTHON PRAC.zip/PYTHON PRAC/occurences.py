def find_occurrences(main_string, sub_string):
    indices = []
    index = main_string.find(sub_string)
    
    while index != -1:
        indices.append(index)
        index = main_string.find(sub_string, index + 1)
    
    return indices if indices else -1

main_str = input("Enter the main string: ")
sub_str = input("Enter the substring to find: ")
result = find_occurrences(main_str, sub_str)

if result == -1:
    print("-1, second string not present in first string")
else:
    print("Indices of occurrences:", result)
