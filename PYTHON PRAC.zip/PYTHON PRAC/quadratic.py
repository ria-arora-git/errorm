import cmath

def quadratic_equation():
    a= float(input("Enter value of a : "))
    b= float(input("Enter value of b : "))
    c= float(input("Enter value of c : "))

    d=(b**2)-(4*a*c)
    root_d=cmath.sqrt(d)

    if(d>0):
        x=(-b+root_d)/(2*a)
        y=(-b-root_d)/(2*a)
        print(f"The roots of the equation are {x},{y}")
    elif(d==0):
        x=-b/(2*a)
        print(f"The roots of the equation are {x},{x}")
    else:
        real_part = -b/(2*a)
        imaginary_part = abs(root_d)/(2*a)
        print(f"The roots of the equation are complex: {real_part} + {imaginary_part}i and {real_part} - {imaginary_part}i")

quadratic_equation()

