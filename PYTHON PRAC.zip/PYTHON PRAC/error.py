def nameCheck(name):
    for char in name:
        if char.isdigit():
            raise ValueError("Name contains a digit, which is not allowed.")
        elif not char.isalnum():
            raise TypeError("Name contains a special character, which is not allowed.")
    return "Name is valid."

name = input("Enter your name: ")
try:
    print(nameCheck(name))
except ValueError as err:
    print("Error", err)
except TypeError as err:
    print("Error",err)
