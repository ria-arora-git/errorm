def count(file):
    with open(file, 'r') as file:
        lines = file.readlines()
    
    total_characters = sum(len(line) for line in lines)
    total_words = sum(len(line.split()) for line in lines)
    total_lines = len(lines)

    print(f'Total characters: {total_characters}')
    print(f'Total words: {total_words}')
    print(f'Total lines: {total_lines}')
    return lines

def char_freq(lines):
    char_frequency = {}
    for line in lines:
        for char in line:
            char_frequency[char] = char_frequency.get(char, 0) + 1
    
    print('Character frequency:', char_frequency)

def words_reverse(lines):
    reverse_words = [word[::-1] for line in lines for word in line.split()]
    print('Words in reverse order:', ' '.join(reverse_words))

def split_even_odd_lines(lines):
    even_lines = [line for index, line in enumerate(lines) if index % 2 == 0]
    odd_lines = [line for index, line in enumerate(lines) if index % 2 != 0]

    with open('File1.txt', 'w') as file1, open('File2.txt', 'w') as file2:
        file1.writelines(even_lines)
        file2.writelines(odd_lines)

def all_parts(file):
        lines = count(file)
        char_freq(lines)
        words_reverse(lines)
        split_even_odd_lines(lines)
    

all_parts('C:\\Users\\Ria\\OneDrive\\Desktop\\PYTHON\\Assignments\\LAB REMAINING\\Input.txt')


