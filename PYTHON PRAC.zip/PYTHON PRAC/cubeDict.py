def print_cube_dict():
    cube_dict = {x: x**3 for x in range(1, 6)}
    print(cube_dict)

print_cube_dict()
