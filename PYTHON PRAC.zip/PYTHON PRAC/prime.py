n = int(input("Enter a number: "))

def prime(num):
    if num <= 1:
        return None
    if num == 2:
        return True
    if num % 2 == 0:
        return False
    for i in range(3, num, 2):
        if num % i == 0:
            return False
    return True

if prime(n) == True:
    print("The number is prime")
elif prime(n) == None:
    print("None")
else:
    print("The number is composite")

def prime_till_num(limit):
    print(f"Prime numbers up to {limit}:")
    for i in range(2, limit + 1):
        if prime(i):
            print(i, end=' ')
    print() 

prime_till_num(n)

def generate_n_primes(n):
    primes = []
    m = 2  
    while (len(primes) < n):
        if prime(m):
            primes.append(m)
        m += 1
    return primes

prime_nums = generate_n_primes(n)

print(f"The first {n} prime numbers are: {prime_nums}")


