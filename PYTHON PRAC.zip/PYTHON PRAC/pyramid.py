def print_pyramid(height):
    for i in range(1, height + 1):
        print(' ' * (height-i), end="")
        print('*' * (2 * i - 1))

def print_reverse_pyramid(height):
    for i in range(height, 0, -1):
        print(' ' * (height-i), end="")
        print('*' * (2 * i - 1))


height = int(input("Enter the height of pyramid : "))

print("Pyramid:")
print_pyramid(height)

print("\nReverse Pyramid:")
print_reverse_pyramid(height)
