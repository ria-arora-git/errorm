def swap_first_n_characters():

    str1 = input("Enter the first string: ")
    str2 = input("Enter the second string: ")
    
    n = int(input("Enter the number of characters to swap: "))
    
    if n > len(str1) or n > len(str2):
        print("Error: n must be less than or equal to the length of both strings.")

    swapped_str1 = str2[:n] + str1[n:]
    swapped_str2 = str1[:n] + str2[n:]

    print(f"First string after swapping: {swapped_str1}")
    print(f"Second string after swapping: {swapped_str2}")

swap_first_n_characters()
