def check(char):
    if char.isalpha():
        print(f"{char} is a letter.")
        if char.isupper():
            print("It is uppercase.")
        else:
            print("It is lowercase.")
    elif char.isdigit():
        print(f"{char} is a numeric digit.")
        digit_names = {
            '0': 'ZERO',
            '1': 'ONE',
            '2': 'TWO',
            '3': 'THREE',
            '4': 'FOUR',
            '5': 'FIVE',
            '6': 'SIX',
            '7': 'SEVEN',
            '8': 'EIGHT',
            '9': 'NINE'
        }
        print(f"The name of the digit is: {digit_names[char]}")
    else:
        print(f"{char} is a special character.")

character = input("Enter a character: ")
check(character)
