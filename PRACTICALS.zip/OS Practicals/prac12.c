#include <stdio.h>
#include <stdlib.h>

void print_alloc(int procs, int blocks, int proc_size[], int alloc[], int block_rem[]) {
    printf("\nProcess No.\tProcess Size\tAllocated Block\tBlock Remains\n");
    for (int i = 0; i < procs; ++i) {
        if (alloc[i] != -1)
            printf("%10d\t%12d\t%14d\t%12d\n", i+1, proc_size[i], alloc[i]+1, block_rem[alloc[i]]);
        else
            printf("%10d\t%12d\t%14s\t%12s\n", i+1, proc_size[i], "Not Allocated", "-");
    }
    printf("\n");
}

void first_fit(int procs, int blocks, int proc_size[], int block_size[]) {
    int *alloc = (int*)malloc(procs * sizeof(int));
    int *block_rem = (int*)malloc(blocks * sizeof(int));
    for (int i = 0; i < blocks; ++i) block_rem[i] = block_size[i];
    for (int i = 0; i < procs; ++i) alloc[i] = -1;

    for (int i = 0; i < procs; ++i) {
        for (int j = 0; j < blocks; ++j) {
            if (block_rem[j] >= proc_size[i]) {
                alloc[i] = j;
                block_rem[j] -= proc_size[i];
                break;
            }
        }
    }

    printf("\n--- First Fit Allocation ---\n");
    print_alloc(procs, blocks, proc_size, alloc, block_rem);

    free(alloc);
    free(block_rem);
}

void best_fit(int procs, int blocks, int proc_size[], int block_size[]) {
    int *alloc = (int*)malloc(procs * sizeof(int));
    int *block_rem = (int*)malloc(blocks * sizeof(int));
    for (int i = 0; i < blocks; ++i) block_rem[i] = block_size[i];
    for (int i = 0; i < procs; ++i) alloc[i] = -1;

    for (int i = 0; i < procs; ++i) {
        int bestIdx = -1;
        int bestRem = 0x7fffffff;
        for (int j = 0; j < blocks; ++j) {
            if (block_rem[j] >= proc_size[i]) {
                int rem = block_rem[j] - proc_size[i];
                if (rem < bestRem) {
                    bestRem = rem;
                    bestIdx = j;
                }
            }
        }
        if (bestIdx != -1) {
            alloc[i] = bestIdx;
            block_rem[bestIdx] -= proc_size[i];
        }
    }

    printf("\n--- Best Fit Allocation ---\n");
    print_alloc(procs, blocks, proc_size, alloc, block_rem);

    free(alloc);
    free(block_rem);
}

void worst_fit(int procs, int blocks, int proc_size[], int block_size[]) {
    int *alloc = (int*)malloc(procs * sizeof(int));
    int *block_rem = (int*)malloc(blocks * sizeof(int));
    for (int i = 0; i < blocks; ++i) block_rem[i] = block_size[i];
    for (int i = 0; i < procs; ++i) alloc[i] = -1;

    for (int i = 0; i < procs; ++i) {
        int worstIdx = -1;
        int worstRem = -1;
        for (int j = 0; j < blocks; ++j) {
            if (block_rem[j] >= proc_size[i]) {
                int rem = block_rem[j] - proc_size[i];
                if (rem > worstRem) {
                    worstRem = rem;
                    worstIdx = j;
                }
            }
        }
        if (worstIdx != -1) {
            alloc[i] = worstIdx;
            block_rem[worstIdx] -= proc_size[i];
        }
    }

    printf("\n--- Worst Fit Allocation ---\n");
    print_alloc(procs, blocks, proc_size, alloc, block_rem);

    free(alloc);
    free(block_rem);
}

int main(void) {
    int blocks, procs, choice;
    int *block_size, *proc_size;

    printf("Enter number of blocks: ");
    scanf("%d", &blocks);

    block_size = (int*) malloc(blocks * sizeof(int));
    for (int i = 0; i < blocks; i++) {
        printf("Size of block %d: ", i+1);
        scanf("%d", &block_size[i]);
    }

    printf("\nEnter number of processes: ");
    scanf("%d", &procs);

    proc_size = (int*) malloc(procs * sizeof(int));
    for (int i = 0; i < procs; i++) {
        printf("Size of process %d: ", i+1);
        scanf("%d", &proc_size[i]);
    }

    while (1) {
        printf("\n1. First Fit");
        printf("\n2. Best Fit");
        printf("\n3. Worst Fit");
        printf("\n4. Show Data");
        printf("\n5. Exit");
        printf("\nChoose: ");
        scanf("%d", &choice);

        if (choice == 1)
            first_fit(procs, blocks, proc_size, block_size);

        else if (choice == 2)
            best_fit(procs, blocks, proc_size, block_size);

        else if (choice == 3)
            worst_fit(procs, blocks, proc_size, block_size);

        else if (choice == 4) {
            printf("\nBlocks: ");
            for (int i = 0; i < blocks; i++) printf("%d ", block_size[i]);

            printf("\nProcesses: ");
            for (int i = 0; i < procs; i++) printf("%d ", proc_size[i]);
            printf("\n");
        }
        else if (choice == 5)
            break;

        else
            printf("Invalid choice.\n");
    }

    free(block_size);
    free(proc_size);
    return 0;
}

