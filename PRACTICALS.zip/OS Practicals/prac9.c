#include<stdio.h>
#define nl printf("\n")

typedef struct {
    int id;
    int bt;
    int wt;
    int tat;
} process;

int main() {
    process p[10], temp;
    int n, i, j;
    float avg_wt = 0, avg_tat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);
    nl;

    for(i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Enter Burst Time for Process %d: ", i + 1);
        scanf("%d", &p[i].bt);
    }

    for(i = 0; i < n - 1; i++) {
        for(j = i + 1; j < n; j++) {
            if(p[i].bt > p[j].bt) {
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }

    p[0].wt = 0;
    for(i = 1; i < n; i++) {
        p[i].wt = 0;
        for(j = 0; j < i; j++)
            p[i].wt += p[j].bt;
    }

    printf("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time");
    for(i = 0; i < n; i++) {
        p[i].tat = p[i].bt + p[i].wt;
        avg_wt += p[i].wt;
        avg_tat += p[i].tat;
        printf("\nP[%d]\t\t%d\t\t%d\t\t%d", p[i].id, p[i].bt, p[i].wt, p[i].tat);
    }

    avg_wt /= n;
    avg_tat /= n;

    nl;
    printf("\nAverage Waiting Time = %.2f", avg_wt);
    printf("\nAverage Turnaround Time = %.2f\n", avg_tat);

    return 0;
}
