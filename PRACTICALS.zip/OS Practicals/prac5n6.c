#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("System Report\n");

    printf("Kernel Version: ");
    system("uname -r");

    printf("CPU Type: ");
    system("uname -m");

    printf("CPU information: ");
    system("cat /proc/cpuinfo | grep 'model name'\n");

    printf("\nMemory Information:\n");
    system("cat /proc/meminfo");

    return 0;
}
