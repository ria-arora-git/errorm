#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        printf("Fork failed!\n");
        return 1;
    }

    if (pid == 0) {
        printf("Child is running... PID: %d\n", getpid());
        sleep(2);
        printf("Child finished.\n");
    } else {
        wait(NULL);
        printf("Parent completed. PID: %d\n", getpid());
    }

    return 0;
}
