#include <stdio.h>
#include <stdlib.h>

void print_alloc(int p,int b,int *ps,int *alloc,int *rem){
    puts("\nProc\tSize\tBlock\tRemains");
    for(int i=0;i<p;i++){
        if(alloc[i]>=0) printf("%d\t%d\t%d\t%d\n", i+1, ps[i], alloc[i]+1, rem[alloc[i]]);
        else           printf("%d\t%d\t-\t-\n", i+1, ps[i]);
    }
}

void allocate_and_print(int mode,int p,int b,int *ps,int *bs){
    int *alloc = malloc(p*sizeof *alloc), *rem = malloc(b*sizeof *rem);
    for(int i=0;i<b;i++) rem[i]=bs[i];
    for(int i=0;i<p;i++) alloc[i]=-1;
    for(int i=0;i<p;i++){
        int best=-1, bestval=(mode==2)?(1<<30):-1;
        for(int j=0;j<b;j++) if(rem[j]>=ps[i]){
            int val = rem[j]-ps[i];
            if(mode==1){ best=j; break; }            
            if(mode==2 && val<bestval){ best=j; bestval=val; } 
            if(mode==3 && val>bestval){ best=j; bestval=val; } 
        }
        if(best!=-1){ alloc[i]=best; rem[best]-=ps[i]; }
    }
    printf("\n--- %s Fit ---\n", mode==1?"First":mode==2?"Best":"Worst");
    print_alloc(p,b,ps,alloc,rem);
    free(alloc); free(rem);
}

int main(void){
    int b,p,choice;
    printf("Enter number of blocks: "); if(scanf("%d",&b)!=1) return 0;
    int *bs = malloc(b*sizeof *bs);
    for(int i=0;i<b;i++){ printf("Size of block %d: ", i+1); scanf("%d",&bs[i]); }
    printf("Enter number of processes: "); if(scanf("%d",&p)!=1){ free(bs); return 0; }
    int *ps = malloc(p*sizeof *ps);
    for(int i=0;i<p;i++){ printf("Size of process %d: ", i+1); scanf("%d",&ps[i]); }

    while(1){
        printf("\n1.First 2.Best 3.Worst 4.Show 5.Exit\nChoose: "); if(scanf("%d",&choice)!=1) break;
        if(choice>=1 && choice<=3) allocate_and_print(choice,p,b,ps,bs);
        else if(choice==4){
            printf("\nBlocks: "); for(int i=0;i<b;i++) printf("%d ", bs[i]);
            printf("\nProcs:  "); for(int i=0;i<p;i++) printf("%d ", ps[i]);
            putchar('\n');
        } else if(choice==5) break;
        else puts("Invalid choice.");
    }

    free(bs); free(ps);
    return 0;
}
