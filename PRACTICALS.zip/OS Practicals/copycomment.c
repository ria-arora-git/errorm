#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>   // for read(), write(), close()
#include <fcntl.h>    // for open()
#include <string.h>

// Custom Getline function: reads one line from a file descriptor
// Returns number of characters read, or 0 if EOF
int Getline(int fd, char *buf, int maxlen) {
    int i = 0;
    char c;
    while (i < maxlen - 1) {
        int n = read(fd, &c, 1);   // read one character
        if (n == 0) {              // EOF
            if (i == 0) return 0;  // no data read
            break;
        }
        if (c == '\n') {           // stop at newline
            buf[i++] = c;
            break;
        }
        buf[i++] = c;
    }
    buf[i] = '\0';  // null terminate string
    return i;       // return number of chars read
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <source_file> <destination_file>\n", argv[0]);
        exit(1);
    }

    int src, dest;
    char buffer[1024];
    int len;

    // Open source file
    src = open(argv[1], O_RDONLY);
    if (src < 0) {
        perror("Error opening source file");
        exit(1);
    }

    // Open/create destination file with rw-r--r-- permissions
    dest = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (dest < 0) {
        perror("Error opening/creating destination file");
        close(src);
        exit(1);
    }

    // Copy line by line using Getline
    while ((len = Getline(src, buffer, sizeof(buffer))) > 0) {
        write(dest, buffer, len);   // write line to destination
    }

    close(src);
    close(dest);

    printf("File copied successfully: %s → %s\n", argv[1], argv[2]);
    return 0;
}
