// Write a program to compute the sum of the first n terms of the following series:
// � = 1 − 1
// 2! +
// 1
// 3" − ⋯ 1
// �#
// The number of terms n is to be taken from the user through the command line. If the 
// command line argument is not found then prompt the user to enter the value of n.


#include <iostream>
#include <cmath>

double calculateSeriesSum(int n) {
    double sum = 0.0;
    for (int i = 1; i <= n; ++i) {
        double term = 1.0 / pow(i, i);
        if (i % 2 == 0) {
            term = -term;
        }
        sum += term;
    }
    return sum;
}

int main(int argc, char* argv[]) {
    int n;
    if (argc > 1) {
        n = std::stoi(argv[1]);
    } else {
        std::cout << "Enter the value of n: ";
        std::cin >> n;
    }

    if (n <= 0) {
        std::cerr << "n should be a positive integer!" << std::endl;
        return 1;
    }

    double result = calculateSeriesSum(n);
    std::cout << "The sum of the series is: " << result << std::endl;
    return 0;
}
