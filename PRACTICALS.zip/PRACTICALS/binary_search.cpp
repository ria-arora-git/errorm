// Write a program to search a given element in a set of N numbers using Binary Search
// a. with recursion
// b. without recursion.


#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

//a. With recursion
int binarySearchRecursive(const vector<int>& arr, int low, int high, int target) {
    if (low > high)
        return -1;

    int mid = low + (high - low) / 2;

    if (arr[mid] == target)
        return mid;
    else if (arr[mid] > target)
        return binarySearchRecursive(arr, low, mid - 1, target);
    else
        return binarySearchRecursive(arr, mid + 1, high, target);
}

//b. Without recursion
int binarySearchIterative(const vector<int>& arr, int target) {
    int low = 0, high = arr.size() - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (arr[mid] == target)
            return mid;
        else if (arr[mid] < target)
            low = mid + 1;
        else
            high = mid - 1;
    }

    return -1;
}

int main() {
    int n, target;
    vector<int> numbers;

    cout << "Enter the number of elements: ";
    cin >> n;

    cout << "Enter " << n << " elements (sorted):\n";
    for (int i = 0; i < n; ++i) {
        int num;
        cin >> num;
        numbers.push_back(num);
    }

    sort(numbers.begin(), numbers.end());

    cout << "Enter the element to search: ";
    cin >> target;

    int resultRec = binarySearchRecursive(numbers, 0, n - 1, target);
    if (resultRec != -1)
        cout << "Recursive: Element found at index " << resultRec << endl;
    else
        cout << "Recursive: Element not found\n";

    int resultIter = binarySearchIterative(numbers, target);
    if (resultIter != -1)
        cout << "Iterative: Element found at index " << resultIter << endl;
    else
        cout << "Iterative: Element not found\n";

    return 0;
}
