// Create a Matrix class. Write a menu-driven program to perform following Matrix 
// operations (exceptions should be thrown by the functions if matrices passed to them are 
// incompatible and handled by the main() function):
// a. Sum
// b. Product
// c. Transpose


#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;

class Matrix {
private:
    vector<vector<int> > data;
    int rows, cols;

public:
    Matrix(int r, int c) : rows(r), cols(c) {
        data.resize(r, vector<int>(c, 0));
    }

    void input() {
        cout << "Enter elements for a " << rows << "x" << cols << " matrix:\n";
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                cin >> data[i][j];
            }
        }
    }

    void display() const {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                cout << data[i][j] << " ";
            }
            cout << endl;
        }
    }

    Matrix operator+(const Matrix& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw invalid_argument("Matrices must have the same dimensions for addition.");
        }
        Matrix result(rows, cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[i][j] = data[i][j] + other.data[i][j];
            }
        }
        return result;
    }

    Matrix operator*(const Matrix& other) const {
        if (cols != other.rows) {
            throw invalid_argument("Number of columns in the first matrix must equal the number of rows in the second matrix for multiplication.");
        }
        Matrix result(rows, other.cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < other.cols; ++j) {
                for (int k = 0; k < cols; ++k) {
                    result.data[i][j] += data[i][k] * other.data[k][j];
                }
            }
        }
        return result;
    }

    Matrix transpose() const {
        Matrix result(cols, rows);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[j][i] = data[i][j];
            }
        }
        return result;
    }
};

int main() {
    int r1, c1, r2, c2;
    cout << "Enter dimensions of the first matrix (rows columns): ";
    cin >> r1 >> c1;
    Matrix m1(r1, c1);
    m1.input();

    cout << "Enter dimensions of the second matrix (rows columns): ";
    cin >> r2 >> c2;
    Matrix m2(r2, c2);
    m2.input();

    while (true) {
        try {
            int choice;
            cout << "\nMenu:\n"
                 << "1. Sum of Matrices\n"
                 << "2. Product of Matrices\n"
                 << "3. Transpose of a Matrix\n"
                 << "4. Exit\n"
                 << "Enter your choice: ";
            cin >> choice;

            if (choice == 4) {
                cout << "Exiting program.\n";
                break;
            }

            switch (choice) {
                case 1: {
                    Matrix sum = m1 + m2;
                    cout << "Sum of matrices:\n";
                    sum.display();
                    break;
                }
                case 2: {
                    Matrix product = m1 * m2;
                    cout << "Product of matrices:\n";
                    product.display();
                    break;
                }
                case 3: {
                    cout << "Transpose of the first matrix:\n";
                    Matrix transposed1 = m1.transpose();
                    transposed1.display();

                    cout << "Transpose of the second matrix:\n";
                    Matrix transposed2 = m2.transpose();
                    transposed2.display();
                    break;
                }
                default:
                    cout << "Invalid choice. Please try again.\n";
            }
        } catch (const exception& e) {
            cout << "Error: " << e.what() << endl;
        }
    }

    return 0;
}
