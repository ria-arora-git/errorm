#include <iostream>
#include <fstream>
using namespace std;

class Student {
    int rollNo;
    string name;
    string className;
    int year;
    float totalMarks;

public:
    void input() {
        cout << "Enter Roll No: ";
        cin >> rollNo;
        cin.ignore();

        cout << "Enter Name: ";
        getline(cin, name);

        cout << "Enter Class: ";
        getline(cin, className);

        cout << "Enter Year: ";
        cin >> year;

        cout << "Enter Total Marks: ";
        cin >> totalMarks;
    }

    void display() const {
        cout << "\nRoll No: " << rollNo
             << "\nName: " << name
             << "\nClass: " << className
             << "\nYear: " << year
             << "\nTotal Marks: " << totalMarks << "\n";
    }

    void writeToFile(ofstream &out) const {
        out << rollNo << endl
            << name << endl
            << className << endl
            << year << endl
            << totalMarks << endl;
    }

    void readFromFile(ifstream &in) {
        getline(in >> ws, name);
        getline(in, className);
        in >> rollNo >> year >> totalMarks;
    }
};

int main() {
    const int numStudents = 5;
    Student students[numStudents];

    ofstream outFile("students.txt");
    cout << "Enter details of " << numStudents << " students:\n";
    for (int i = 0; i < numStudents; ++i) {
        cout << "\nStudent " << i + 1 << ":\n";
        students[i].input();
        students[i].writeToFile(outFile);
    }
    outFile.close();

    ifstream inFile("students.txt");
    Student temp;
    cout << "\n--- Student Records from File ---\n";
    for (int i = 0; i < numStudents; ++i) {
        temp.readFromFile(inFile);
        temp.display();
    }
    inFile.close();
    return 0;
}
