// Create a Triangle class. Add exception handling statements to ensure the following 
// conditions: all sides are greater than 0 and sum of any two sides is greater than the third 
// side. The class should also have overloaded functions for calculating the area of a right 
// angled triangle as well as using Heron's formula to calculate the area of any type of 
// triangle

#include <iostream>
#include <stdexcept>
#include <cmath>

class Triangle {
private:
    double a, b, c;

public:
    Triangle(double side1, double side2, double side3) {
        if (side1 <= 0 || side2 <= 0 || side3 <= 0)
            throw std::invalid_argument("All sides must be greater than 0.");
        
        if ((side1 + side2 <= side3) || 
            (side1 + side3 <= side2) || 
            (side2 + side3 <= side1))
            throw std::invalid_argument("Sum of any two sides must be greater than the third side.");

        a = side1;
        b = side2;
        c = side3;
    }

    double area() const {
        double s = (a + b + c) / 2.0;
        return std::sqrt(s * (s - a) * (s - b) * (s - c));
    }

    double area(double base, double height) const {
        if (base <= 0 || height <= 0)
            throw std::invalid_argument("Base and height must be greater than 0.");
        return 0.5 * base * height;
    }

    void printSides() const {
        std::cout << "Sides: " << a << ", " << b << ", " << c << std::endl;
    }
};

int main() {
    try {
        Triangle t1(3, 4, 5);
        t1.printSides();
        std::cout << "Area (Heron's formula): " << t1.area() << std::endl;
        std::cout << "Area (Right-angled triangle): " << t1.area(3, 4) << std::endl;
    } catch (const std::invalid_argument& ex) {
        std::cerr << "Error: " << ex.what() << std::endl;
    }

    return 0;
}
