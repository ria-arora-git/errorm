// Write a menu driven program to perform string manipulation (without using inbuilt string 
//     functions):
//     a. Show address of each character in string
//     b. Concatenate two strings.
//     c. Compare two strings
//     d. Calculate length of the string (use pointers)
//     e. Convert all lowercase characters to uppercase
//     f. Reverse the string
//     g. Insert a string in another string at a user specified position


#include <iostream>
#include <string>
using namespace std;

int main() {
    int choice;
    string str1, str2;
    int pos;

    do {
        cout << "\nMenu:\n";
        cout << "1. Show address of each character\n";
        cout << "2. Concatenate strings\n";
        cout << "3. Compare strings\n";
        cout << "4. Length of string\n";
        cout << "5. Convert to Uppercase\n";
        cout << "6. Reverse string\n";
        cout << "7. Insert string\n";
        cout << "8. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1:
                cout << "Enter string: ";
                getline(cin, str1);
                for (size_t i = 0; i < str1.length(); i++) {
                    cout << str1[i] << " -> " << (void*)&str1[i] << endl;
                }
                break;

            case 2:
                cout << "Enter first string: ";
                getline(cin, str1);
                cout << "Enter second string: ";
                getline(cin, str2);
                {
                    string result = str1;
                    for (size_t i = 0; i < str2.length(); i++) {
                        result += str2[i];
                    }
                    cout << "Concatenated: " << result << endl;
                }
                break;

            case 3:
                cout << "Enter first string: ";
                getline(cin, str1);
                cout << "Enter second string: ";
                getline(cin, str2);
                {
                    bool equal = true;
                    if (str1.length() != str2.length()) {
                        equal = false;
                    } else {
                        for (size_t i = 0; i < str1.length(); i++) {
                            if (str1[i] != str2[i]) {
                                equal = false;
                                break;
                            }
                        }
                    }
                    cout << (equal ? "Strings are equal." : "Strings are not equal.") << endl;
                }
                break;

            case 4:
                cout << "Enter string: ";
                getline(cin, str1);
                {
                    size_t length = 0;
                    while (str1[length] != '\0') {
                        length++;
                    }
                    cout << "Length: " << length << endl;
                }
                break;

            case 5:
                cout << "Enter string: ";
                getline(cin, str1);
                for (size_t i = 0; i < str1.length(); i++) {
                    if (str1[i] >= 'a' && str1[i] <= 'z') {
                        str1[i] = str1[i] - 'a' + 'A';
                    }
                }
                cout << "Uppercase: " << str1 << endl;
                break;

            case 6:
                cout << "Enter string: ";
                getline(cin, str1);
                {
                    size_t n = str1.length();
                    for (size_t i = 0; i < n / 2; i++) {
                        swap(str1[i], str1[n - 1 - i]);
                    }
                    cout << "Reversed: " << str1 << endl;
                }
                break;

            case 7:
                cout << "Enter main string: ";
                getline(cin, str1);
                cout << "Enter string to insert: ";
                getline(cin, str2);
                cout << "Enter position: ";
                cin >> pos;
                cin.ignore();
                if (pos >= 0 && pos <= str1.length()) {
                    string result = str1.substr(0, pos) + str2 + str1.substr(pos);
                    cout << "Result: " << result << endl;
                } else {
                    cout << "Invalid position!" << endl;
                }
                break;

            case 8:
                cout << "End of program!\n";
                break;

            default:
                cout << "Invalid choice.\n";
        }
    } while (choice != 8);

    return 0;
}
























// #include <iostream>
// #include <string>
// #include <algorithm> 
// using namespace std;

// int main() {
//     int choice;
//     string str1, str2;
//     int pos;

//     do {
//         cout << "\nMenu:\n";
//         cout << "1. Show address of each character\n";
//         cout << "2. Concatenate strings\n";
//         cout << "3. Compare strings\n";
//         cout << "4. Length of string\n";
//         cout << "5. Convert to Uppercase\n";
//         cout << "6. Reverse string\n";
//         cout << "7. Insert string\n";
//         cout << "8. Exit\n";
//         cout << "Enter choice: ";
//         cin >> choice;
//         cin.ignore(); 

//         switch (choice) {
//             case 1:
//                 cout << "Enter string: ";
//                 getline(cin, str1);
//                 for (size_t i = 0; i < str1.length(); i++)
//                     cout << str1[i] << " -> " << (void*)&str1[i] << endl;
//                 break;

//             case 2:
//                 cout << "Enter first string: ";
//                 getline(cin, str1);
//                 cout << "Enter second string: ";
//                 getline(cin, str2);
//                 cout << "Concatenated: " << str1 + str2 << endl;
//                 break;

//             case 3:
//                 cout << "Enter first string: ";
//                 getline(cin, str1);
//                 cout << "Enter second string: ";
//                 getline(cin, str2);
//                 cout << ((str1 == str2) ? "Strings are equal." : "Strings are not equal.") << endl;
//                 break;

//             case 4:
//                 cout << "Enter string: ";
//                 getline(cin, str1);
//                 cout << "Length: " << str1.length() << endl;
//                 break;

//             case 5:
//                 cout << "Enter string: ";
//                 getline(cin, str1);
//                 for (char &c : str1) c = toupper(c);
//                 cout << "Uppercase: " << str1 << endl;
//                 break;

//             case 6:
//                 cout << "Enter string: ";
//                 getline(cin, str1);
//                 reverse(str1.begin(), str1.end());
//                 cout << "Reversed: " << str1 << endl;
//                 break;

//             case 7:
//                 cout << "Enter main string: ";
//                 getline(cin, str1);
//                 cout << "Enter string to insert: ";
//                 getline(cin, str2);
//                 cout << "Enter position: ";
//                 cin >> pos;
//                 cin.ignore();
//                 if (pos >= 0 && pos <= str1.length())
//                     str1.insert(pos, str2);
//                 else
//                     cout << "Invalid position!" << endl;
//                 cout << "Result: " << str1 << endl;
//                 break;

//             case 8:
//                 cout << "Goodbye!\n";
//                 break;

//             default:
//                 cout << "Invalid choice.\n";
//         }
//     } while (choice != 8);

//     return 0;
// }
