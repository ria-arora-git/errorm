// Write a program that prints a table indicating the number of occurrences of each alphabet  in the text entered as command line arguments.

#include <iostream>
#include <string>
#include <cctype>
#include <map>

int main() {
    std::map<char, int> frequency;
    std::string text;

    for (char ch = 'a'; ch <= 'z'; ++ch) {
        frequency[ch] = 0;
    }

    std::cout << "Enter text: ";
    std::getline(std::cin, text);

    for (char ch : text) {
        if (std::isalpha(ch)) {
            ch = std::tolower(ch);
            frequency[ch]++;
        }
    }

    std::cout << "\nAlphabet Frequencies:\n";
    for (char ch = 'a'; ch <= 'z'; ++ch) {
        if (frequency[ch] > 0) {
            std::cout << ch << " : " << frequency[ch] << '\n';
        }
    }

    return 0;
}
