Triangle t2(1, 2, 3); // Invalid triangle
        Triangle t3(0, 4, 5); // Side <= 0
        std::cout << t1.area(-2, 3); // Invalid base/height