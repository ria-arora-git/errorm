//Copy the contents of one text file to another file, after removing all whitespaces

#include <iostream>
#include <fstream>
#include <cctype>  

using namespace std;

int main() {
    string sourceFile = "12.txt";
    string destFile = "12output.txt";

    ifstream inFile(sourceFile);
    ofstream outFile(destFile);

    if (!inFile) {
        cerr << "Error opening source file.\n";
        return 1;
    }

    if (!outFile) {
        cerr << "Error creating destination file.\n";
        return 1;
    }

    char ch;
    while (inFile.get(ch)) {
        if (!isspace(static_cast<unsigned char>(ch))) {
            outFile.put(ch);
        }
    }

    inFile.close();
    outFile.close();

    cout << "File copied to '" << destFile << "' without whitespaces.\n";
    return 0;
}
