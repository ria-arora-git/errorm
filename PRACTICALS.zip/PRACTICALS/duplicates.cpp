// Write a program to remove the duplicates from an array.

    #include <iostream>
    #include <vector>
    #include <unordered_set>

    using namespace std;

    vector<int> removeDuplicates(const vector<int>& arr) {
        unordered_set<int> seen;
        vector<int> result;

        for (int num : arr) {
            if (seen.find(num) == seen.end()) {
                seen.insert(num);
                result.push_back(num);
            }
        }
        return result;
    }

    int main() {
        int n;
        cout << "Enter the size of the array: ";
        cin >> n;

        if (n <= 0) {
            cerr << "Array size must be positive!" << endl;
            return 1;
        }

        vector<int> arr(n);
        cout << "Enter the array elements:" << endl;
        for (int i = 0; i < n; ++i) {
            cin >> arr[i];
        }

        vector<int> uniqueArray = removeDuplicates(arr);

        cout << "Array after removing duplicates:" << endl;
        for (int num : uniqueArray) {
            cout << num << " ";
        }
        cout << endl;

        return 0;
    }













// #include <iostream>

// int main() {
//     int n;
//     std::cout << "Enter the size of the array: ";
//     std::cin >> n;

//     if (n <= 0) {
//         std::cerr << "Array size must be positive!" << std::endl;
//         return 1;
//     }

//     int arr[100]; // assuming max size is 100
//     std::cout << "Enter the array elements:" << std::endl;
//     for (int i = 0; i < n; ++i) {
//         std::cin >> arr[i];
//     }

//     int unique[100]; // array to store unique elements
//     int uniqueSize = 0;

//     for (int i = 0; i < n; ++i) {
//         bool isDuplicate = false;

//         // Check if arr[i] already exists in unique[]
//         for (int j = 0; j < uniqueSize; ++j) {
//             if (arr[i] == unique[j]) {
//                 isDuplicate = true;
//                 break;
//             }
//         }

//         // If not a duplicate, add it to unique[]
//         if (!isDuplicate) {
//             unique[uniqueSize] = arr[i];
//             uniqueSize++;
//         }
//     }

//     std::cout << "Array after removing duplicates:" << std::endl;
//     for (int i = 0; i < uniqueSize; ++i) {
//         std::cout << unique[i] << " ";
//     }
//     std::cout << std::endl;

//     return 0;
// }
