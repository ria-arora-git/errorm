// Define a class Person having name as a data member. Inherit two classes Student and 
// Employee from Person. Student has additional attributes as course, marks and year and 
// Employee has department and salary. Write display() method in all the three classes to
// display the corresponding attributes. Provide the necessary methods to show runtime 
// polymorphism

#include <iostream>
#include <string>
using namespace std;

class Person {
protected:
    string name;

public:
    Person(string n) : name(n) {}
    virtual void display() {
        cout << "Name: " << name << endl;
    }
    virtual ~Person() {}
};

class Student : public Person {
private:
    string course;
    int marks;
    int year;

public:
    Student(string n, string c, int m, int y)
        : Person(n), course(c), marks(m), year(y) {}

    void display() override {
        cout << "Student Details:" << endl;
        cout << "Name: " << name << endl;
        cout << "Course: " << course << endl;
        cout << "Marks: " << marks << endl;
        cout << "Year: " << year << endl;
    }
};

class Employee : public Person {
private:
    string department;
    double salary;

public:
    Employee(string n, string dept, double sal)
        : Person(n), department(dept), salary(sal) {}

    void display() override {
        cout << "Employee Details:" << endl;
        cout << "Name: " << name << endl;
        cout << "Department: " << department << endl;
        cout << "Salary: " << salary << endl;
    }
};

int main() {
    Person* p;

    Student s("Ananya", "B.Tech CSE", 92, 2);
    p = &s;
    p->display();

    cout << endl;

    Employee e("Rahul", "Finance", 72000);
    p = &e;
    p->display();

    return 0;
}
