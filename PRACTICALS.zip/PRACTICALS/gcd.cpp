// Write a program to calculate GCD of two numbers
// a. with recursion
// b. without recursion.
// a. GCD with Recursion

#include <iostream>

int gcdRecursive(int a, int b) {
    if (b == 0)
        return a;
    return gcdRecursive(b, a % b);
}

int main() {
    int num1, num2;
    std::cout << "Enter two numbers: ";
    std::cin >> num1 >> num2;

    int result = gcdRecursive(num1, num2);
    std::cout << "GCD (using recursion): " << result << std::endl;

    return 0;
}

// b. GCD without Recursion

#include <iostream>

int gcdIterative(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main() {
    int num1, num2;
    std::cout << "Enter two numbers: ";
    std::cin >> num1 >> num2;

    int result = gcdIterative(num1, num2);
    std::cout << "GCD (without recursion): " << result << std::endl;

    return 0;
}
